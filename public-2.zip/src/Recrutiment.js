import React from 'react'
import Header from './Header'
import Dashboard from './Dashboard'
import Recruitment1 from './Recruitment1'
function Recrutiment() {
  return (
    <div style={{overflow:'hidden'}}>
           
          <Recruitment1/>

    </div>
  )
}

export default Recrutiment
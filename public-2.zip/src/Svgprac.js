import React from 'react'
import ellipse from './images/Ellipse 26.png'
import './App.css'
import clock from "./images/582-5828759_blank-clock-face-twenty-five-to-four-clock-removebg-preview 1.png";

function Svgprac() {
  return (
    <div>
                  
         <img src={ellipse} className="f-1"/>    
        <img src={clock} className="f-2"/>

    </div>
  )
}

export default Svgprac